-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Jeu 17 Novembre 2016 à 01:58
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `restaurant`
--
CREATE DATABASE IF NOT EXISTS `restaurant` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `restaurant`;

-- --------------------------------------------------------

--
-- Structure de la table `booking`
--

DROP TABLE IF EXISTS `booking`;
CREATE TABLE IF NOT EXISTS `booking` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `User_Id` int(11) NOT NULL,
  `CreationTimestamp` datetime NOT NULL,
  `BookingDate` date NOT NULL,
  `BookingTime` datetime NOT NULL,
  `TableSize` tinyint(4) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `User_Id` (`User_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `booking`
--

INSERT INTO `booking` (`Id`, `User_Id`, `CreationTimestamp`, `BookingDate`, `BookingTime`, `TableSize`) VALUES
(1, 1, '2014-06-21 17:37:11', '2015-01-01', '0000-00-00 00:00:00', 2);

-- --------------------------------------------------------

--
-- Structure de la table `meal`
--

DROP TABLE IF EXISTS `meal`;
CREATE TABLE IF NOT EXISTS `meal` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `Photo` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `BuyPrice` float NOT NULL,
  `SalePrice` float NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Contenu de la table `meal`
--

INSERT INTO `meal` (`Id`, `Name`, `Description`, `Photo`, `BuyPrice`, `SalePrice`) VALUES
(1, 'Coca-Cola', 'Mmmm, le Coca-Cola avec 10 morceaux de sucres et tout plein de caféine !', 'coca.jpg', 0.6, 3),
(2, 'Bagel Thon', 'Notre bagel est constitué d''un pain moelleux avec des grains de sésame et du thon albacore, accompagné de feuilles de salade fraîche du jour  et d''une sauce renversante :-)', 'bagel_thon.jpg', 2.75, 5.5),
(3, 'Bacon Cheeseburger', 'Ce délicieux cheeseburger contient un steak haché viande française de 150g ainsi que d''un buns grillé juste comme il faut, le tout accompagné de frites fraîches maison !', 'bacon_cheeseburger.jpg', 6, 12.5),
(4, 'Carrot Cake', 'Le carrot cake maison ravira les plus gourmands et les puristes : tous les ingrédients sont naturels !\r\nÀ consommer sans modération', 'carrot_cake.jpg', 3, 6.75),
(5, 'Donut Chocolat', 'Les donuts sont fabriqués le matin même et sont recouvert d''une délicieuse sauce au chocolat !', 'chocolate_donut.jpg', 3, 6.2),
(6, 'Dr. Pepper', 'Son goût sucré avec de l''amande vous ravira !', 'drpepper.jpg', 0.5, 2.9),
(7, 'Milkshake', 'Notre milkshake bien crémeux contient des morceaux d''Oréos et est accompagné de crème chantilly et de smarties en guise de topping. Il éblouira vos papilles !', 'milkshake.jpg', 2, 5.35);

-- --------------------------------------------------------

--
-- Structure de la table `meal_menu`
--

DROP TABLE IF EXISTS `meal_menu`;
CREATE TABLE IF NOT EXISTS `meal_menu` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Meal_Id` int(11) NOT NULL,
  `Menu_Id` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Meal_Id` (`Meal_Id`),
  KEY `Menu_Id` (`Menu_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Contenu de la table `meal_menu`
--

INSERT INTO `meal_menu` (`Id`, `Meal_Id`, `Menu_Id`) VALUES
(1, 1, 1),
(2, 3, 1),
(3, 4, 1);

-- --------------------------------------------------------

--
-- Structure de la table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `SalePrice` float NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Contenu de la table `menu`
--

INSERT INTO `menu` (`Id`, `Name`, `SalePrice`) VALUES
(1, 'Sweet Dreams', 18.5);

-- --------------------------------------------------------

--
-- Structure de la table `order`
--

DROP TABLE IF EXISTS `order`;
CREATE TABLE IF NOT EXISTS `order` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `User_Id` int(11) NOT NULL,
  `CreationTimestamp` datetime NOT NULL,
  `CompleteTimestamp` datetime DEFAULT NULL,
  `TotalAmount` float DEFAULT NULL,
  `TaxRate` float NOT NULL,
  `TaxAmount` float DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `User_Id` (`User_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `order`
--

INSERT INTO `order` (`Id`, `User_Id`, `CreationTimestamp`, `CompleteTimestamp`, `TotalAmount`, `TaxRate`, `TaxAmount`) VALUES
(1, 1, '2014-06-21 17:37:28', NULL, NULL, 20, NULL),
(2, 2, '2016-11-17 01:44:59', NULL, NULL, 20, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `orderline`
--

DROP TABLE IF EXISTS `orderline`;
CREATE TABLE IF NOT EXISTS `orderline` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Order_Id` int(11) NOT NULL,
  `Meal_Id` int(11) NOT NULL,
  `Menu_Id` int(11) DEFAULT NULL,
  `Quantity` tinyint(4) NOT NULL,
  `UnitPrice` float NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Order_Id` (`Order_Id`),
  KEY `Meal_Id` (`Meal_Id`),
  KEY `Menu_Id` (`Menu_Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `orderline`
--

INSERT INTO `orderline` (`Id`, `Order_Id`, `Meal_Id`, `Menu_Id`, `Quantity`, `UnitPrice`) VALUES
(1, 1, 3, NULL, 3, 12.5),
(2, 1, 6, NULL, 5, 2.9);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `LastName` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `Address` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `ZipCode` char(5) COLLATE utf8_unicode_ci NOT NULL,
  `City` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Phone` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `Birthday` date NOT NULL,
  `CreationTimestamp` datetime NOT NULL,
  `LastLoginTimestamp` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`Id`, `FirstName`, `LastName`, `Email`, `Password`, `Address`, `ZipCode`, `City`, `Phone`, `Birthday`, `CreationTimestamp`, `LastLoginTimestamp`) VALUES
(1, 'test', 'test', 'test@test.com', '$2y$11$b61b8c9f08c18c61f9236Out0GS7uMYk7dqF9yMKC4ZJMu72jw0tu', '9 Novembre 1976', '19760', 'Novembre', '0123456789', '1976-11-09', '2014-06-21 17:36:44', '2014-06-21 17:36:56'),
(2, 'test', 'testeur', 'toto0126@yopmail.fr', '$2y$11$153e84c93307d556cc67cu5A8vf5kSyEk0nWqaSfcv6hAg.QaJTmC', 'rue des vieux', '75000', 'paris', '0123456789', '1945-01-03', '2016-11-17 01:44:30', '2016-11-17 01:44:47');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `Booking_ibfk_1` FOREIGN KEY (`User_Id`) REFERENCES `user` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `meal_menu`
--
ALTER TABLE `meal_menu`
  ADD CONSTRAINT `Meal_Menu_ibfk_1` FOREIGN KEY (`Meal_Id`) REFERENCES `meal` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Meal_Menu_ibfk_2` FOREIGN KEY (`Menu_Id`) REFERENCES `menu` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `order`
--
ALTER TABLE `order`
  ADD CONSTRAINT `Order_ibfk_1` FOREIGN KEY (`User_Id`) REFERENCES `user` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `orderline`
--
ALTER TABLE `orderline`
  ADD CONSTRAINT `OrderLine_ibfk_1` FOREIGN KEY (`Order_Id`) REFERENCES `order` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `OrderLine_ibfk_2` FOREIGN KEY (`Meal_Id`) REFERENCES `meal` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `OrderLine_ibfk_3` FOREIGN KEY (`Menu_Id`) REFERENCES `menu` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
